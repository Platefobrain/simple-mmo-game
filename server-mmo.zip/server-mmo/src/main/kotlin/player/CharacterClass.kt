package pl.decodesoft.player

import kotlinx.serialization.Serializable

// Wyliczenie dostępnych klas postaci
enum class CharacterClass {
    ARCHER, // Łucznik
    MAGE,   // Mag
    WARRIOR // Wojownik
}

// Rozszerzenie klasy player data o klasę postaci i zdrowie
@Serializable
data class PlayerData(
    var x: Float,
    var y: Float,
    val id: String,
    val username: String = "",
    val characterClass: CharacterClass = CharacterClass.WARRIOR, // Domyślnie wojownik
    var maxHealth: Int = 100, // Maksymalne zdrowie
    var currentHealth: Int = 100 // Aktualne zdrowie
) {
    // Metoda do ustawiania wartości zdrowia
    fun setHealth(health: Int) {
        currentHealth = health.coerceIn(0, maxHealth)
    }

    // Metoda do otrzymywania obrażeń
    fun takeDamage(damage: Int) {
        currentHealth = (currentHealth - damage).coerceIn(0, maxHealth)
    }

    // Metoda do leczenia
    fun heal(amount: Int) {
        currentHealth = (currentHealth + amount).coerceIn(0, maxHealth)
    }
}

// Dodaj do User informację o wybranej klasie postaci i zdrowiu
@Serializable
data class User(
    val id: String,
    val username: String,
    val passwordHash: String,
    var characterClass: CharacterClass = CharacterClass.WARRIOR, // Domyślnie wojownik
    val createdAt: Long = System.currentTimeMillis(),
    var maxHealth: Int = 100, // Maksymalne zdrowie zależne od klasy
    var currentHealth: Int = 100 // Aktualne zdrowie
)

// Klasa dla żądania wyboru postaci
@Serializable
data class CharacterSelectRequest(val userId: String, val characterClass: Int)

// Klasa dla odpowiedzi wyboru postaci
@Serializable
data class CharacterSelectResponse(val success: Boolean, val message: String)