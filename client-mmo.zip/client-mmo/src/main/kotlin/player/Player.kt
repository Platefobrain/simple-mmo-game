package pl.decodesoft.player

import com.badlogic.gdx.graphics.Color

// Klasa Player wyodrębniona do osobnego pliku
data class Player(
    var x: Float,
    var y: Float,
    val id: String,
    val color: Color = Color.RED,
    val username: String = "Unknown",
    val characterClass: Int = 2, // 0-łucznik, 1-mag, 2-wojownik
    var isSelected: Boolean = false, // Dodana flaga zaznaczenia
    var maxHealth: Int = 100, // Maksymalny poziom zdrowia
    var currentHealth: Int = 100 // Aktualny poziom zdrowia
) {
    // In Player class, add a method to indicate death state
    fun isDead(): Boolean = currentHealth <= 0

    // Metoda do pobierania koloru specyficznego dla klasy postaci
    fun getClassColor(): Color {
        return when (characterClass) {
            0 -> Color(0.2f, 0.8f, 0.2f, 1f) // Zielony dla łucznika
            1 -> Color(0.2f, 0.2f, 0.9f, 1f) // Niebieski dla maga
            else -> Color(0.9f, 0.2f, 0.2f, 1f) // Czerwony dla wojownika
        }
    }

    // Metoda do pobierania nazwy klasy postaci
    fun getClassName(): String {
        return when (characterClass) {
            0 -> "Łucznik"
            1 -> "Mag"
            else -> "Wojownik"
        }
    }
}